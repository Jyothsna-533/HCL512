import 'bootstrap/dist/css/bootstrap.min.css';
import { Navbar, Button, Nav } from 'react-bootstrap';
import React, { useState } from 'react';
import './App.css';
import { BrowserRouter as Router, Link, Switch, Route, Redirect } from 'react-router-dom';
import Home from './home';
import Adminlogin from './adminlogin';
import UserLogin from './userlogin';
import Userdetails from './userdetails';
import Adminaxios from './adminaxios';
import Useraxios from './useraxios';
import Adduser from './adduser';
import Edituser from './edituser';
import Viewuser from './viewuser';
import CurrentBalence from './currentadd';
import MiniStatement from './mini';
import AddAmount from './addamount';

function App(props) {

  return (
    <div className="App">

      <Router>
        <Navbar bg="dark" variant="dark" sticky="top">
          <Navbar.Brand href="#home">
            <img
              alt=""
              src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTitkvCLtsexYuv65RWq8T6K8jIYo9H5rtH5w&usqp=CAU"
              width="35"
              height="35"
              className="d-inline-block align-top"
            />{' '}
      ABC Retail Banking
    </Navbar.Brand>


          <Navbar.Collapse className="justify-content-end">
            <Nav.Link>
              <Link to="/userlogin"> Login</Link>
            </Nav.Link>

            <Nav.Link>
              <Link to="/home"> Logout</Link>
            </Nav.Link>
            
            <Nav.Link>
              <Link to="/home"><img
                alt=""
                src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAANkAAADpCAMAAACeGmLpAAAAolBMVEUgOXL+/v7////t7e3s7Oz29vb5+fnz8/Pw8PD19fUAJmj5/P8OLmgAJGjCydfS1uIaNXATMW7m6fEvRHcLLGl0f59ibpIAKWkAIWQVMm4AJGU3TH6JlK6aoLfc4Onw8fRLW4Wttca3v9F9iadmdJakrMF4hKQAHmM/UH67w9SFkKvy9vxSYoonPXCVnrciOnHL0eFDVoHW3exodpaosMWEj6koX0mCAAAPcUlEQVR4nO2dC3equhKAJQgBVAhIBWyLj6p96K721PP//9pNAspDQCRBwz531l5rZzkV8plkMsnk0ZOwAE2W5b4KcErBKRkC8mmffAi6qpZ7KTKSUvqlX++W+v9k3VPLPUBE62NRSUohKUhSEkn1u6vuaUQItKSTlEJSKv2QpKTuqnuk4Pq0SkJciH2FmBmVFKdGS7vfVXWGTI71UvHXu6X+m8loa5NIw4MkpZCUSlIabaGsajlWK7RR0PYt05fzeHiluqcSgUQUklJISk8+ZFNL5MUDJwzD5eIsVhg6YIv/WJHafHcv6hX6Zx+FpEivANKdxq1qYo7hzLGWx83TeBz4o5GXiDHyvfGfydP32nHIDy7zfXesbqOn1nF2t+b66WOPeWwb9QolsF0PEz69LMIZ1CTA593t+SAyLqpw+fZhG14ZUkYQ5vPGq9cw6mvF9UEkx3z7mdaDSuhQ4Pr7p+VW0mR+PojcU3SF/COSTsUJpb5albbmLzJsdBPWWXAp79YhtttN3l2k7smcLO9suXKN2worL4Hn7xaOjkuOi9Vn76ll/PTwBXkBC1UsyPNWS2xRxPBBIPjc+S4HrEhsb/+NewMOZKQboEY361f2469fUWvQ+f5j8CiulLjemxN5MAxZ6yXduV7d2xeq1fBt7zE1rmKxvYkFFKassVh9GVpvHr9qmGPzdxZTh9S0p8aOLXS+pnZLXESCd8J2dx8Em/kX1FZ5JWwbR2nug5T4ldIVl3c59lrmImJPXxx4W9YyZSbB85QCHUfpJJWaUrhQg3BntGA3isT9c1ThDVk7q5uMPCXnbcrZzlcImk4c9S4+CADWuO0GlhV7+jrD7altHwRIL6M7VcREvLkFWbyrfjVZpA7vYjnyEqA1vJq1QrKotkaFAk6zdrQyZ9SytPbvXmCRTFczXF/Ks3aR89t8kMHEeAwXFruHa2Q7Pggeq/Ta9DmuCfLXsB0fBCzfH1QTT+Jv+jp/Mhm8+I/lwuLtHO4zPLLzey+vo0qCvVO7ndHyoO4J6RXkKFZDUpH3IkdqMNjdt3cuE7Q3dS2TtbKc14syAWf8SNuRFvS+uJwmKch5PR8EOOh+fuJV8RcKL+9KCxvOIbYk/qIW2XVfX7PEAsNoyzq+/nmyRKMpRcOpaIpEi2ZQcP8sGBgpNTUVZSrO+dUoE3DEA8Ne5FFnjjIJWGJEpgvI5oPIkphgBI3JB5GduSj92IUETqUPIvd0InGEJpPCSRVMHjHMrCdo6CilOb8aZfoSFwwP2H4cueEMD1i8Pzr3leJOZg19EEtsMDyo+dKryKLaSP1KWqbUrySNcSua63Ep3pEYjHzO4ygTbXJRrIY2Ptqdk9RgJ6xZTASFBTm/FmV6Edl6nCT4mck3zvAA6/FzA3UEN7XbfBAgDYVvZJH4B+2mKBN4EmNyoIYMHbk4ykQaWxyricYCJFYDTNENfiL2r5rKeTSKKY8yOR2pilR8szAIddFT0+SqAwb/LGjv1PVBwKEbdvEk7pteM8oEPgSaqaohyDC1EjL5XGZkPhK8Pi7g0kyC3SwzkxqRXfggctgl8xGJ/1nHB1Ge2NbyPULQ8+C6D6KZ086BYSfr9TrZbNct8xEJ6g2uzfCo5vTRuWwk3quUb2dn2xjFaqRWi6y9eo6GW1AZZdJa7aTb/NFwS6uMMultFpm7anMA4Q5AhXeltTmp4x/BS4s+AC200iiTvmmvyKZkNub70j4FxlnYXhAURpmi8ZnktLcuYrqk6z1f8+042BzMk4yZ3uAtlMz4LD2mBq9tzeogb0mriATWOTRcic4yZvpd0XhW1lMDqa0SQ+5nBIbfdRxlVLR5RBpGsh52+cvIli01cGSbp+wTtExbc/mR2b+wzAeZtGM/0PCQgGGCRbrUOJL13DDtg6TmV8N2uhs0tNJgBC1VajzJvKOUmiM+zetji/ndChkK/smCYYZlgsaTDM1Bal4/6akHP20YkAKwDBpHC4IfFmpFPojVhv1AvfASLI1mPwHAjcx9hRdRJuIftFAZg30hGMb4PHWd3iZG40CGPkgAI/ZBToFdtY3KaI9LwCha/D4vLjUOZLg6KnGcOokyyRZ//yN4dsrACJqbReNCtr6c4YH8K6NdBYbfap7RVnSPIAcye0LemPVBdO7d9BUwMhc9PKPRfoedrOeSoXU2yuQMmZ+aFfvjChgxx8EJbYLHjTzIjE8AUlEmPIrRTc423/7YXgPDaOEZbTfgUmb2F4hGMfA88uTZzHAG3Z8aYAQNpdA4kGG7n4sygTlXm+/Oa4Gl0dzdlgNZbxrm9sUMuE4zurtBPbAs2jOHV3sLLUvG1bVyJ7XBCNppGpJLrbG/YCbKBNYc++mbwAjanmNLQDs9nkmNfBD4yy9+690GRtD+8OxLpYwPMvvg9rN5qxvBJLLRgR+a72R8EIfTpDeK3IlbhSeaYYIUGeTWTxunMcmtaM+80NxvkJrhgQtOBmT61giMoH1waun2BiRRpj4vD2T01RAMo205oaEfJTUPAjZcnjp9aQzGEc1zUj01s29Fv26wgBE0PkvopykyGTxzMPqMYBSNR6MwzFSUacshbGZ8M4LxQsNk1Ncnp9ZJDrs/PH1lBpP4bLp013oSZWLvzvw1BzA+aO4LTHrqT9Z9t/6RCxgXNPc7RcZaZv6SDxdFY92LE0xg4oOwxTrR9JMbGAc09AOjKBPZ8vjCVAO4ghG0FdsPPQfnKBNkIUMeXzAypfrEgobJwMm7YiHjD8aKhsnIQ1jJkGtyB2NEO5Mx1UbkHloAI2ibxuaa1MZTlKmxBUHI4tSPFaA1LTU0l+huSMrXlGz8z2mRCleoSL4ajrIjqx/31I3JPp6p7C1+aMDcRw/9aZYnTKYnPkjzdhbJO1cyP34qIxlgIotlxJWM0dXDtfEcZfrbyOg5DXTkqf1dZPMkyqSxPkwosmCS+CB/F5n7kiYbXf9C58joylTWeRChyOKVXJEP8leRGaaWRJkctmcJR5b4IArjHLFQZNOtnJDpv2wxHqHI/JiMtjP9i21GXSSyeGFqP1rfCBjjZyKRBTs9tdIFHNg6NJHI7C89vR6EMWRRSQaKpD0yLzoJ67zShW1tQRUZcIqk4u8ZyaZWdi8T2+rGSrKnqZuX6aRFMideUUafpuls45hqsku7a7dHhn5AvJeJPkzTlkzG8VayoD0y+y13Yh6b5ygQmfGZI5sxRaoFIvNDkN3LBJnWTQhE9ue8qj2+m0T6ZHmeOGTBSj3dqhL3Z2DLYhzFIfMWWn4vE9NiF4HIwpgs2cvEFNEVhoxs+bnYy2QxOMXCkLnf8LyX6XRNmsKyplwYMuOgnniSHazwrbndF4UMjc87WFO7jjWGbVqikNlfRfup5UHz6igKmXFI76eWpHh3P/hq3KUJQoY+6HFd6b1M9Go0NWz8SEHI3G81dbts6hSN5ov2BSHzZiUn5sHGW0jEIMNPLTvTxQkaFtrIKpzGiaSYrFwak03NMrLmXdroIA3KpGhdOSYr//umZKQzS5Ol74mHYdNNJMGwXAq/UPH3TRu7twaZG+7PPgg9yWvSpSMpc+I6cvmJeeIfiF0u9husPFeO73bPe4pvaZVkh24eK0eOqtFzp/Zm2xmQ+G2xu6/4oZy7EyF3aq/a1ilDLYv9Sxkqbw7o5PmNvalFDpKuPrW3ky3N3uQvWCwg62ShISd/3WfRvUxOFw7Wz4r3Ai9Px6aeCHFJ5NPts0qBCyu2oOcBzrmMGSBhUOVUlElOn0LfqfPMifgmKLnrOHdzAFx3y/Lbq1OZXL0TQemWEXGdQrKcD0LPmNadztyI0Iu2YYKC07HjKNNpmkeJ5kg6dKi5vQOpnCc4pyiTlL1hEc47Ux89J3UzAOnPLk/MS98BpLV04iF/8Reg8hbnPFln7KP7C0rvpy66oQMPAvTfLpQaGm/zOc9GmQqud1O3PPbFty3Tg1p2MV35vUzgIL6TZRyVgpzno0wXdwDBhehNzds0vBtSfxPb6w8+BpV3Q1KyqEypnpZpFKuZtXq4Oqsg7FWV5JzWxtj90PWoE1dISo+7c30m8s0xtiWV5ZxakMuRZ9p2bl1hDeT7GsqVNwKX9NSnW5xNUdH8hV6Z86v3U2sHMdH8I+jL/bpk/Qu/EoA+XIo41W88gdLb0k8esXa61E2iJ6Eo0unofUhPe8G6tXho3hOIJm8qcl59I3C/T1JH0S4N857IgcpXcn71fmryoWClZmxm56w1vp86+rqybBrAbkP8DZAbkvXzZBo8iHMJ5vsRpLNWlnP5Yr5RLigzTYYHZAtxuzh6X4BLsoKcX0SZ8j35WT34EcGHRENTxz5hNmvNfJCk05itHj+osZEFC7LWyAdJvq7DrwfHn5A3H0hFWWMkg7JyRA91/cmxlyVZKyKr286IGloPbGwBWlZkraCdETyJrtyMokzUwtAPSUrOqsGM6bwmFvHmoV6VtYucF0WZLvuzpNPQF+gREz9o+kJrWknWCnJezwdJq2E4v7+NdPcmuJ61Bt5VRq3N1j1SbPfrt9FoMwB1snY9ypTz9fNqdTu5p/fvPS8Lw0jXfP3zKEeNRjnnq9FgcklaXg3V4/5eRtL2vgegftYSdUmU6Twy7Rer4ezLvYclQd7KAeCmrF2JMl3vDpXtilxD22prQ97Pkp7rd1vWbvdBcmpg/fhtgiFv/DrTGmUtIrvBB7lQmx/tXR+MuRwoN84a6JG9P2pBlCmO1ZSo1SilDsz5tI32hrw/rzNJbZK1JMok3Wz1sVpK1OHvlPeF1rb/s8Tl1aBDqhdlqtEd9umcpPPv3uA3CAi895UFNTI5xZI1DmRkmmS23I08LgWHi+t1G8+SMpI1q405tazBcD03WCfKbQP9HuKHX59QvFYbVWwN1NQFkdmUXluNf7fw+9nzmlZLZBu9zecsWmhz47sL1WxWP6vGbo1znCDjZoOCbM+d/2vOGN7NMsNTQy2Tp2/Ntx0y3Jp4KHCN4XyzsGZQY3o3Tx+kRA0kCB3z9Xc39D03KK+cQeB6I/dj8mpii6FoXN5dQHarR3xNrekADMLl62qyHxqjkRcd5WK7OOFhIGM0HE4m67UZzqIVGjzffRFlumEUU09NLLGqbrehFS7XVCbf9L+jZVkDas4gbOndZBTDZFrrqenGKfohxChq0vxbfTeXnlpENR8fRET1LbNy3VLLt82kdkl90+x3p9T8e2pB1C34IIKo/2YygVsKYzuj0EkYqSQC3z11zVUTHVT/R3wQwfLGPMPTpr/9SHXmrAm6lo7YzmgtHZHuqv8H+EKnVRTWOQ0AAAAASUVORK5CYII="
                width="27"
                height="27"
                className="d-inline-block align-top"
              /></Link>
            </Nav.Link>


          </Navbar.Collapse>
        </Navbar>

        <Switch>
          <Route exact path="/" > <Redirect to='/Home' /></Route>




          <Route path="/UserLogin" component={UserLogin}></Route>
          <Route path="/Home" component={Home}></Route>


          <Route path="/adduser" component={Adduser}></Route>
          <Route path="/adminaxios" component={Adminaxios}></Route>
          <Route path="/edituser/:id" component={Edituser}></Route>
          <Route path="/viewuser/:id" component={Viewuser}></Route>
          <Route path="/useraxios" component={Useraxios}></Route>
          <Route path="/addamount" component={AddAmount}></Route>
          <Route path="/currentadd" component={CurrentBalence}></Route>
          <Route path="/mini/:id" component={MiniStatement}></Route>



        </Switch>
      </Router>

      {/* <Switch>
          <Route exact path="/" ><Redirect to="/home"></Redirect></Route>
          <Route path="/home" component={Home}></Route>
          <Route path="/userlogin" component={Userlogin}></Route>
          <Route path="/userdetails" component={Userdetails}></Route>
          <Route path="/adminlogin" component={Adminlogin}></Route>

          <Route path="/adduser" component={Adduser}></Route>
          <Route path="/addamount" component={AddAmount}></Route>
          <Route path="/adminaxios" component={Adminaxios}></Route>
          <Route path="/edituser/:id" component={Edituser}></Route>
          <Route path="/viewuser/:id" component={Viewuser}></Route>

        </Switch>
      </Router> */}

      {/* <Userdetails /> */}
      {/* <Usercurrentdetails/>
      <Usersavingdetails/> */}

    </div>
  );
}

export default App;
