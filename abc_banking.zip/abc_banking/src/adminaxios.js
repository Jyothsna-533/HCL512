import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { Link, BrowserRouter as Router, Route, Switch } from 'react-router-dom';
import { Navbar, Button, Card, Form, Row, Col } from 'react-bootstrap';
import { Container } from 'react-bootstrap';
import Adduser from './adduser';
import Edituser from './edituser';
import Viewuser from './viewuser';

function Adminaxios(props) {

    const [users, setUser] = useState([]);

    useEffect(() => {
        loadUsers();
    }, []);

    const loadUsers = async () => {
        const result = await axios.get("http://localhost:3003/users");
        setUser(result.data.reverse());
    }

    const deleteUser = async id => {
        await axios.delete(`http://localhost:3003/users/${id}`);
        loadUsers();
    }
    const userL = () => {
        props.history.push('/adduser');
    }

    const viewUser = (id) => {
        props.history.push(`/viewuser/${id}`);
    }

    const edituser = (id) => {
        props.history.push(`/edituser/${id}`);
    }
    return (
        <div>
            <center>
                <h3 style={{ backgroundColor: 'lightsteelblue' }}>Admin Dashboard </h3>
                {/* <Link class='btn btn-outline-danger btnAdd' to={'/home'} block style={{marginLeft:'1100px',marginTop:'5px'}}>Logout</Link> */}
                {/* <div style={{ backgroundImage: `url("data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBxAQDw0PDw8PDQ0NDw8NDRANDQ8PDw0NFREWFhUSFRUYHSggGBolGxUVITEhJSkrLi4uFx8zODMtNygtLisBCgoKDQ0NDg8PDysZFRk3KysrNystLTcrLSstKysrKy03KysrKysrKysrKysrKysrKysrKysrKysrKysrKysrK//AABEIALcBEwMBIgACEQEDEQH/xAAaAAEBAQEBAQEAAAAAAAAAAAAAAQMCBAUH/8QAMRABAQABAwMCBAUCBwEAAAAAAAECAxEhMUFREnEEYYGxEyKRodFSwRQyQoKi8PEF/8QAFQEBAQAAAAAAAAAAAAAAAAAAAAH/xAAWEQEBAQAAAAAAAAAAAAAAAAAAARH/2gAMAwEAAhEDEQA/AP17d1MvLjPDboku6jvLFnli7xy/Rc0E0Nfn03r2r0ZY7zavH6Xo0dTtfpfKjKaF356efLStmeWJRwmS1lnkgkuzXTz3/llhjvfu9Fkk2UWV1GNnjq1xl256gtixYsBGWee/s71d9uGOOO92Bppzf2a2pOOEQWBAFAgKBAUFBEUBEVKAioAADjLHdhnh3jXS1JlPn3nh1nio8uOXbu02WYbe6ZUFxw3TUjiZWctcbL7gujq9r17Xy2seXPBpp6vbLr58g417sxxm92j1alxym1+nHRnp4+n52g7xkxmxJb7LMfP6O4YEmy7CXI0Mkmd9wQX1Lu5UFEUFgAKACkAFAABAEqoAioAAD5+9lnp5vjy90caelt87eq6meyi3FnqRphlLN4ZYg8tib7NcsWdxBrhqb8Xr91yxeevRpb2c/TzQSTfo0xx291kUA3S5OdwW0RUBUigLEUBUWAKiwCKigKgCgAAgKgAIACADnW1Zj874ZXKZdL/LDUvN36s87so3x3xu86d49OOW83nRn6Py4783bn3ZY5em/K9Qb5xnW3WcM8og49LuZVyoO5kXJzAFIAKACqgCwAFABQAURQUQBQAAQFQAEAAAHnyxlZaejvlJ2nNd2tvhpxv5+yjTKcPNqR6NS8PPkUc6Op6eO32b5R5curTS1NuL0+yDui5RIAqKBFRQURQURQURQFQBVQBRFBRAFEAUQBUAAEAAB87e7zGczK7e3zfTxm0knbh5fhcN8rl/TxPd6NTLaVRndTm+OznKMpXeOW3sDPUjltqY7zhkg9Eu8ns5NG8X5LQAgCqgCqgCgAoAKIoCoAoACoAogCiAAAAIAAC6WG02+t93GvezSZcbvPqVaMcse8Mcv1ducsEF9Wzn1S9PrE38s5xl78KPTo3n3justO7We7fOIOFRQFRQFRQFQBVQBQAURQAAFQBRAFEAAAAABFBno59ZU1MWMqb2dKtGmw4/Fvfl1NXHvwgmWLzav5bL2j2SS9LKz1tPeANcNXtfpWGHSGSj02OWenq7cXmfZttvzEEABRFBRFAVAFABRAFABRAFEAUQBUAAEBRAHjxv7NcJvx37PPlxWmGWyhnNnFerOSzfyyuCDz5cN/g7ll6t7bJxz5cZ4vb8NpenGT633UeaxcZvu715y5w6wGWUdYalnt4a6mmxyxQenGyzeI8uOVnMenT1Jl8r4BRbEBRFgCmxsAACiAKAAqAKIAogAAACAogDy6mDOV9D8KH4GP8ATL78qMPh8t98frHdwbY4ydJJ7RaYPPjpfmm84nL0ucTLOTrdlHGelv3JoT536uc/icZ5vtP5c/4vfpjfrdkHo2jjPS3ZzWtm+0n7vNqfEZ7/AObafKQHeppbMWuhnbbLbd5xuuppg70tbfjLr58tbi8X4Vvyn6tpbJJvdp5BrcpGOpq3twbL6PINPhNeZflvGc/5R6PQ8no25nFejS1d/edQTKOWtZ2IAgCiKAAAAAAAAACAogDm/FeMb9bIz1Pisu0n13rkoMr8TqX/AFbe0jT4fO5b43K29evbuw1Zs1/+Zhvcs/8Abj/f+yj6Mjz6t3rbO8V5rSjnKOdP7NNnGM2tQa6feMNXC87TdtjeVUY6WlZZbenaNbd3GerJ874jvT5m/wD2A5rHU1L2m3zr0bOMsEGWjrXG8/ml6x7MbLN48WWCaepcbvP/AFR7a4s25nV1pakynHF7xbEHeGe/v3W157xzGmOW6jqxFlSxAEAUAAAAAAEBRAFEAYAAw+J/d9HQ0vRjjjO0/fuCwSaktyx/p2cegAX0ss+qgBrY8ADzyN/h71n1UB1UBBzliwzwUBlLZd5xY9uhr+ri8ZftQUd5Ysrx0UQdbuscu36AotQEAAAAAAAAAAEAB//Z")`,
               width: '1300px', height: '800px' }}>
 */}

                <Router>
                    <Button onClick={userL}>Add User</Button><br /><br />

                    {/* <Link to="/adduser">Add User</Link> */}

                    <Container>
                        <table class="table border shadow" style={{ backgroundImage: `url("data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBxAQDw0PDw8PDQ0NDw8NDRANDQ8PDw0NFREWFhUSFRUYHSggGBolGxUVITEhJSkrLi4uFx8zODMtNygtLisBCgoKDQ0NDg8PDysZFRk3KysrNystLTcrLSstKysrKy03KysrKysrKysrKysrKysrKysrKysrKysrKysrKysrK//AABEIALcBEwMBIgACEQEDEQH/xAAaAAEBAQEBAQEAAAAAAAAAAAAAAQMCBAUH/8QAMRABAQABAwMCBAUCBwEAAAAAAAECAxEhMUFREnEEYYGxEyKRodFSwRQyQoKi8PEF/8QAFQEBAQAAAAAAAAAAAAAAAAAAAAH/xAAWEQEBAQAAAAAAAAAAAAAAAAAAARH/2gAMAwEAAhEDEQA/AP17d1MvLjPDboku6jvLFnli7xy/Rc0E0Nfn03r2r0ZY7zavH6Xo0dTtfpfKjKaF356efLStmeWJRwmS1lnkgkuzXTz3/llhjvfu9Fkk2UWV1GNnjq1xl256gtixYsBGWee/s71d9uGOOO92Bppzf2a2pOOEQWBAFAgKBAUFBEUBEVKAioAADjLHdhnh3jXS1JlPn3nh1nio8uOXbu02WYbe6ZUFxw3TUjiZWctcbL7gujq9r17Xy2seXPBpp6vbLr58g417sxxm92j1alxym1+nHRnp4+n52g7xkxmxJb7LMfP6O4YEmy7CXI0Mkmd9wQX1Lu5UFEUFgAKACkAFAABAEqoAioAAD5+9lnp5vjy90caelt87eq6meyi3FnqRphlLN4ZYg8tib7NcsWdxBrhqb8Xr91yxeevRpb2c/TzQSTfo0xx291kUA3S5OdwW0RUBUigLEUBUWAKiwCKigKgCgAAgKgAIACADnW1Zj874ZXKZdL/LDUvN36s87so3x3xu86d49OOW83nRn6Py4783bn3ZY5em/K9Qb5xnW3WcM8og49LuZVyoO5kXJzAFIAKACqgCwAFABQAURQUQBQAAQFQAEAAAHnyxlZaejvlJ2nNd2tvhpxv5+yjTKcPNqR6NS8PPkUc6Op6eO32b5R5curTS1NuL0+yDui5RIAqKBFRQURQURQURQFQBVQBRFBRAFEAUQBUAAEAAB87e7zGczK7e3zfTxm0knbh5fhcN8rl/TxPd6NTLaVRndTm+OznKMpXeOW3sDPUjltqY7zhkg9Eu8ns5NG8X5LQAgCqgCqgCgAoAKIoCoAoACoAogCiAAAAIAAC6WG02+t93GvezSZcbvPqVaMcse8Mcv1ducsEF9Wzn1S9PrE38s5xl78KPTo3n3justO7We7fOIOFRQFRQFRQFQBVQBQAURQAAFQBRAFEAAAAABFBno59ZU1MWMqb2dKtGmw4/Fvfl1NXHvwgmWLzav5bL2j2SS9LKz1tPeANcNXtfpWGHSGSj02OWenq7cXmfZttvzEEABRFBRFAVAFABRAFABRAFEAUQBUAAEBRAHjxv7NcJvx37PPlxWmGWyhnNnFerOSzfyyuCDz5cN/g7ll6t7bJxz5cZ4vb8NpenGT633UeaxcZvu715y5w6wGWUdYalnt4a6mmxyxQenGyzeI8uOVnMenT1Jl8r4BRbEBRFgCmxsAACiAKAAqAKIAogAAACAogDy6mDOV9D8KH4GP8ATL78qMPh8t98frHdwbY4ydJJ7RaYPPjpfmm84nL0ucTLOTrdlHGelv3JoT536uc/icZ5vtP5c/4vfpjfrdkHo2jjPS3ZzWtm+0n7vNqfEZ7/AObafKQHeppbMWuhnbbLbd5xuuppg70tbfjLr58tbi8X4Vvyn6tpbJJvdp5BrcpGOpq3twbL6PINPhNeZflvGc/5R6PQ8no25nFejS1d/edQTKOWtZ2IAgCiKAAAAAAAAACAogDm/FeMb9bIz1Pisu0n13rkoMr8TqX/AFbe0jT4fO5b43K29evbuw1Zs1/+Zhvcs/8Abj/f+yj6Mjz6t3rbO8V5rSjnKOdP7NNnGM2tQa6feMNXC87TdtjeVUY6WlZZbenaNbd3GerJ874jvT5m/wD2A5rHU1L2m3zr0bOMsEGWjrXG8/ml6x7MbLN48WWCaepcbvP/AFR7a4s25nV1pakynHF7xbEHeGe/v3W157xzGmOW6jqxFlSxAEAUAAAAAAEBRAFEAYAAw+J/d9HQ0vRjjjO0/fuCwSaktyx/p2cegAX0ss+qgBrY8ADzyN/h71n1UB1UBBzliwzwUBlLZd5xY9uhr+ri8ZftQUd5Ysrx0UQdbuscu36AotQEAAAAAAAAAAEAB//Z")`,
               width: '1000px', height: '800px' }}>
                            <thead class="thead-dark">
                                <tr>
                                    <th scope='col'>#</th>
                                    <th scope='col'>Name</th>
                                    <th scope='col'>Username</th>
                                    <th scope='col'>Email</th>
                                    <th scope='col'>Action</th>
                                </tr>

                            </thead>
                            <tbody>

                                {
                                    users.map((user, index) => (
                                        <tr>
                                            <th scope='row'>{index + 1}</th>
                                            <td>{user.name}</td>
                                            <td>{user.username}</td>
                                            <td>{user.email}</td>

                                            <td>

                                                <Link class='btn btn-outline-primary' onClick={() => viewUser(user.id)} to={`/viewuser/${user.id}`}>View</Link>{' '}
                                                <Link class='btn btn-outline-info' onClick={() => edituser(user.id)} to={`/edituser/${user.id}`}>Edit</Link>{' '}
                                                <Link class='btn btn-outline-danger' onClick={() => deleteUser(user.id)}>Delete</Link>{' '}

                                            </td>
                                        </tr>
                                    ))

                                }

                            </tbody>
                        </table>
                    </Container>
                    <Switch>
                        <Route path="/adduser" component={Adduser}></Route>
                        <Route path="/edituser/:id" component={Edituser}></Route>
                        <Route path="/viewuser/:id" component={Viewuser}></Route>
                    </Switch>
                </Router>
                {/* </div> */}
            </center>


        </div>

    )
}

export default Adminaxios;