import { Navbar, Button ,Card,Form} from 'react-bootstrap';
import React, { useState } from 'react';
import Adminaxios from './adminaxios';

function Adminlogin(props) {

    const[username,setUsername]=useState('');
    const[password,setPassword]=useState('');
    

    const usernameinputvalchange = (e) => {

        setUsername(e.target.value);

    }
    const passwordinputvalchange = (e) => {
        setPassword(e.target.value);

    }

    const onSubmit = () => {

        const usernameRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/;
        const passwordRegex = /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[^a-zA-Z0-9])(?!.*\s).{8,15}$/;
        const isUsernameValid = usernameRegex.test(username);
        const isPasswordValid = passwordRegex.test(password);
    
        if (isUsernameValid && isPasswordValid) {

            props.history.push('/adminaxios')
        } 

        else {
            alert("Invalid Credentials")
        }

    }
   
   
    return (

        <div style={{backgroundColor:'lightgrey'}}>
            <center>
            <Card style={{ width: '23rem' ,marginTop:'50px',backgroundColor:'whitesmoke',border:'1px solid black'}}>
                <Card.Body>
                    <Card.Title>Admin Login </Card.Title><br/>

                    <Form>
                        <Form.Group controlId="formBasicEmail">
                            <Form.Label style={{marginRight:"240px"}}>  <img alt=""
                                src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAOoAAADXCAMAAAAjrj0PAAAAllBMVEX39/cAev////8AcP8Acv8Adf8AeP8Ab/8Adv/9+/f//ff//vb6+fcAbf8Ae/////bq8v/1+f/v9f/N3//Y5vjy9fd+rv/U4/89jf+1z//t8vfE2f+91P8nhP+ox//f6/9hnv+Ruf+Hs/+Uu/sdgf9xp/9VmP+iwvuryfrN3vkfg/9Hkf+BsP9qo/+WvP+Mtv9Rlf/U4/ioYQczAAAL6klEQVR4nO2deZeqOBOHxSxACFwUtXGhRXFt9+//5SZo223f2wupCmDP8fnrPTPnHfpnVSqVSiVpNB48ePDgwYMHDx7Uj5SuK4RwG90rDSnyf+BKWfffZgwlUgjZiVb7eRonM4sxW+Gw4CXepNOsvx54SvGv16tUuuFon774hFLmOFxhvZL/b4cxSmwaz5e54F+rV8lsrJdpkGt80/c5SjJhSa8fuuL3qZWuFz6nFvlR5a1eSpLesPGrjKvsecoSnxaX+SZX+XO6Gnhu3RKK4YpOlhCmLfOKQ+mi371/T5ZC9o8InVe1Tu9036aVXnhg1MHpPMMdO1417ta0UpxStEFv1FJrMrhLsfJPdLRNGPRGLGPb+xMrvWhjWOhFLJkORN3ibpGicyTmhZ5h9NC9nwAlBvOyhFq5Za3VnXixdDPKShN6FkuStXcHYsU6oaUKvYid1+7FruzZxqaX72B8VK9hvWhWru++w+10UJ9hpdxWY9ILjA/rmndEJy5/lN7C7W09CzyvX+IM8wU0Dqt3YulWFI8+4rDKnVgONtU67xVOMq9SpW4nqNx5r5BdlQNWDGkNznuFxYPKtHorUqNSNWBnVQUnL/PrFJprdTqVaPWmpGal+WrnVIHWP3egNK/GrEufdO7BpjmcrEu2670oPdu1VK3e5F6U5uO1zNgklnXH3lu4E5Y2v4qRXbe8DzizsnIJd11v5vAvTlyOVBmaq9ybgqXl5P5JbRn+15CshOnVS/FVpEtDwCuUaewzf4k9NB6GRYacZjijfrDoLfvR01jxFPWXvaPlU+So4Mx0GHbXqGmGUxJPh+3mP4SjLWbbWeEkZs0quwHiz2Ekfg7/lXllvJ9hqlS0Z3S4IgYqZ6Q3/lrnhSj14WKNDlexAg9Uhx5aPwk9mzYFV+U4N5dJyAG0vsLt9JMB+jlP4L0fJ/1jSqo4Ar3L4cOiQnMmPvAXtfuGXNiFui/dFPLdG8M6sN+UO2ZcWA6AMz2Z6wlVtGcwrWxuJEH0drDoS3raSpvNFjD7JJEBs0pg8kD1bXrWCpvA+YuByVXEoG87G5BSNevAVop0iY5MwJjEuWZEemcFWv9zp4u2Ksyh7AiqtNmcg2IDmyJdWCxB8zqdwpU2mzOYC2OXOKBVB59hlDYjUCBkc5RZRQZyJqKVJP1LCppxbJRZu6DsARx9r4xBoZBhVnMubKRiYtKFHcistA03qwQFCB5jlTbHsNF6AJvV7YMciT6jpTZBeQvn4LnVgyVKPjh7eOcZNsc9A1MmuQYZ1VnglTbbIA/mL8AFjpjDgoMB/202E5BDQRc4XVgBhPxYNCvCFDShO7A0woWNF85NKG2OYL8zHUCkAldvBqaanDFsf5OuAIFJdmAVJQe2JP+bFqwa4WwAgcmFpb9qHjcitQncTiCARPgPLAZabGlGKmwlB6lGQP1XfatWqQAPdpfAXRqW1SrVItolYbEAVvRrHqsW1a70A/OHfAPFiNI2+Pu6WYQcQj+FLLZciaB7fzzQtKqAJWY5zMDCBrq0ybE7eoMVmCqdP1VjDpyjO90M4O0sdGRCKqySluPstAarHML7WcxMrMAExsqDhZZVoVlhDpuakIpoHdLLDQXcf5QDGVDaQjRu0pGOVA/Ru8OxVeAcWCX4AptoeLAMEUejjEysTwipTqoRl4AFtFeoAamIsKh+a42GF3eFOfBmG5Dax/wBVKMcjMiVcqm11YFfIRr5EiYAqy8V7soqSapOCEakhYak7jFuxTRSQ8kxUuvbyLhK1egV6GKaf41MNuA1XI5GFgyuK51hewNSwUWIs9RjcamoabXOjYwLvHjjN7wEkX/HMqEUupHx+icUjsCoDIInRqRiMkOLFJcKLYyepZrZswkxZ9L8wukSZrV6F1LtwrVgnNR7cODCmaF7wEgNjEjFREYNqbhsnxopjsI6piqWSp5MSO2h/oSqrLoyIRW34KhmrBraNkedf9aQionAFn8xoBQVgCuTamQRh4pKOvMqJlsys5MB3d294BcUmrdRon5TE4MVd28VLZwDo1Y2Rpq0RqihyoPiUlHrVXw/O2Yf7ixVY72KqkIY6BEAdwe8fr94FaLRQN5fQr45bl0EVL1Qb4dVWrhj/Qxy8u8G5K0COo3tuDqwwkeZdYK8gUKn2RtX3beQnd4h9qIjOixe3cclwTkE0eq9wV6gorNng9uJu3wOXCI9oL+tsxOHnVgtTAc/Nk7oHVaQA/Qvy7ZQqehP63XzeNC+zTfAhUNMF8QFlul08wjYobRbCFAqPkzoBGD0ivUsFXgGEP8j653ZNRCXoJ1aqK3dHP6i2WOI/m2BpW9cpSVHtyEYnRqq5BA0s27RI0f3qA0+X7LYBCIVs4V8QbcfWKJ26M+AGgVMfFb79An+fjtIMQK7zoCcAEQvbkDLG9RW4wW9vtEc4DnHD+i3tuODkkW0D2FL9KoR0BncMvDNhf75P+BB8w/oFiP2eE+CnOoE3gnxAd35Br3IyM/q6p90RLU/v6I530T4oATxX8Q9dzfYJx2pqO3jC/on4nIMVF00jz3i/Zcz4CUY+Dttter8bQPxF3hjjcA7lNbyBr+oscgJdi+EPKHDBGcaUg3kvzH0OsM/G/QyuVqpsKB0NitumzOX6lQplQdAoQr3BWlWrYn1CTteGOIOc+R8w5mv0yvQogQV88EzzRkJLgpwh9J4r9mYNpoHNnzDEXeTIfTKGkacXR90BmWcbQjglfAc/WsSPmrVNqsypx9PMH2GLZhxsddTao5WZU6ergwcKXrax5rGxV+HLIufhHYomR3Q9/q90e7vHI0r+Sn6CQl3WGgKUOYki+8u14cRHRK/mHExc+qVAms5zuxZD92r9AXh84IVMC4xcHO57Hzb2aOiEIkzI6eIvqQ17AU/qIVnv7d4Xy9wlNvSFDap6DLex9+5MnRJ8zefTzjKbV+25qLQz7T76Vdxim3NvJPhfvLkVAVu+ynRp65sIiZdEB8fA+GOclsTkyeM09mVP0j1I1MPgsiba4LV8AzmZUXbooTPR3qj1tADA2fc14VrrnNr5GwJmlY/vS6E+Ax/Ofs7Xn5rupo9D/eh85WRUqvE2mZfPFT5oTOtIQz9xHDD8RnhX1I7hJm5dtIsrYBtTD+fJvq2beiGQpPELDD/2KHXo36VCUMh5rSUZ1jdDWPGly449sRelfG4ruzOnMDIgU1TjHzaM/bq1EetY4eZOV1thiebLcp6MNmNCDvWLfCNMWVxSUIb+VuzPjVzzyaekDmzbomv1osVoSZuecMTWk6AeCeiAN7SBjwUZp4wYHxcqlKlNbsHHw4t5oSlv1fvZTY18V4ChjFTNi1dqdL6bFMTVxXCiRibVaE0T4d9ltSYS6jPz8p70fwvrUPKHK02HZPsfRaXOcv8pfVkMdKvR+mOkFRWplTlTYOE+dMahLYTamMfhNNEyh3RfnMUz5Ax2i/n1fZvEJnNeMUL2KnNglO1Nr1ojXi1ThzGlCyqC0i3uIMFoUlltbVnwsjSq0WpGrBiqT5v5NrCHwmP6metw3mviE6s/oIKisMZUYOlyjnmX6TIKPPnJYfi6IWqH7RGk14QyrWYU2bdNExtRib1mvSC9EYWJTMjDwt8xpQwexHWbtILrpwwRpJS9uf2hKr/cl2B9xNEe65icWxabGvCKQ1WbiULtqJIr7PzlWWNXAH3SrillPJl466E5iixc+Vs7GBoByBKfRUBlvLuhOZIEW4dqpI3fIRqZ7N8jK7uU2iOFN1lYlPCe5h1QKt/tCm100jcrdAzrreeMwJX214tbPV/f8kG4n6i7lco0/YXKqAQJ33WXAtEk5gonUFv7br3L/SM6w1Waf5H+8FuWSxDbg8nG0qU3wbbSP4Cg74jXdEYbhOS4ye7bDj+Mk1uP/UPC8fOfxl2zE7er9L5ihRuONrGzlmvzYI47U2W/eHwKcoZjlbZYb5IrPO/JjRYZFFX/Ba//Rcphdc9rbaLwCdfYZNktx+N3V8s8w3lzMJrdIarfS89xsnLLCdIkngxny7761AIpfL3y3xHSldJFt7Vdq7r5Rr/XyIfPHjw4MGDBw9+Mf8B8zY1hoxjiTYAAAAASUVORK5CYII="
                                width="28" height="26" className="d-inline-block align-top"/> User ID</Form.Label>
                            <Form.Control type="email" placeholder="Enter Username" onChange={usernameinputvalchange}/>
                            <Form.Text className="text-muted" style={{marginRight:"55px"}}>We'll never share your email with anyone else.</Form.Text>
                        </Form.Group>

                        <Form.Group controlId="formBasicPassword">
                            <Form.Label style={{marginRight:"230px"}}><img alt=""
                                src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAOEAAADhCAMAAAAJbSJIAAAA1VBMVEX///8Ae/8Ad/8Ac/8Adf9tp/8AcP8Aef8Acv+ewf+71f8Abv+30v/4/P/F2/8Aff+jxv+yz//k7/+Ds/9fn//h7f/w9v8ihP9Pl//b6f9+r/9Vmv9opP8fgv87jv+ry/+OuP/r9P/Q3/8vif+Uvf9zq//P4v+fw/9/sf84jf/z9fbEzNmlssieq8XV2+JYdKgASLgAYN4AbfEAXM2Koc23wdILa99NjfOSpMNYf8ELX8QAYto9e9qLqeAAbOkUUaBbidY/aKlsjcd3mtkAS6BtmOQAV9XVc6U7AAANF0lEQVR4nO1da3viuBWOJUVybLANJsFAgBAgyaTT6Vw63d63293u//9JtQlgmUiW5CNbzPPwfpxJHL+WdO5H5+rqggsuuOCCCy64wAruJtEg2aTb+9GswOh+m26SQTS5c/1icKyiZJrNEaU+xoSgEoRg7FOK5tk0iVauX7MZhr00wzkzghjzZGAMkZwpztLe0PULG6EfbGOac5MyO0XOk8bboO/6xfWwSjKKkXzdpOuJMM2Ss9+xd8kip2fM7riWmC6Sc5Y/wYxi88U7WUpMZ4FrImIMU+Q3X73KSvooPT/BE81CAl2+EoyEs8g1pQoGY2pn+UogOh64pnVEEvv2lq8E8+PENbUdEgaWLlKOmLnnuPRa4/fG0Vs65ReNW9mfFY7+2J3MGWa0bX47jjRzpDtS6/JTBkRTB/yiGHfErwCOu96q/euwiw1agoXXnXoeESGd8itASIfLuO14Ad/Awm1H/G7j7hfwDSS+7YJgrxMVIQajvfYJpqEzfgXCtvVGP+tSR4iAs1Zl6nDs6giWIOMWLZwJIARjDwhP2iIYOFES78HClgI5gzMhWFBsxf1P3ArRKsIWPOOHcyKYU3ywTpC65nQCapmiDYK7LEyBIltzbhThZxBhOr++6T0W6N1czyGx/z1snsUBkCAjNFtWcy6rZUahIWR7EjUAEiT4RWSGDF8w0EKypRcnMD3IwqnMkuxPoY+2Yt0MYQFRvK7z6W7XIEueYQs2an8MEglKbwfmjaEx3NPIIGeFUfVJCUAeNcmgBFPILmL0SeNPPIEoYqBL3IPsIT2CUIohKLBxCzJltIU5TB1RSHgqBu2fjeCJd3eiQoSND/g7LG5OcAuRMmhx+rhouka5WYrWL+9iuwuIwCaN46gRaPP4J6UxN15uphV7guVGnHdT/c8VZBG9sGE0vA+yG0/2aFTNpLLTVMsGJLNJM614DdKErPKsh3fmGTvxYWuq39Qg100IwvYofq58LJFMpvf8jzyDzLdG+xQkR6v75kV8yvwX7mdgZ6KJPAUZMx7ixZvUbKgo6y3I/jU3bYawsIX/qLM6lZV+BIlTj5p6GRksyIC5R03lEotMuZ+DZUSQoQkewZYQzbglrJNYIbeIM9hHpWbCZgwLoRBOodcKSV7k3sBiGmxsQnAJOxOez33PWoOMcaZdBP2jJtVTIE3hVcz9fv3xwuU2hTkyZhojgaZBcelATOrfm5axpDvwX9UPoIIsKK+IbpfPUuw9zO1naCT8xFJscwn5P9VT7FJO6UM/rP4iQk+hEUMubg1mqHsSoYLUHUNdcQrUhZ5Dhno6EWjO7P6QK4Z6hg3QeCrgjiFvLsowtJDNdsfQC9UuRmqhJsghQ6L2E20koB0y5I0NMQKwqvCcMvR8VaDdgpxxy1Ala+6sFJW4ZOjR+v5FsEm6g1OGCuN0YeWPOGXI3uVLeKzsVD45ZejRul5iO5vUMcPabQqMIR7glmFdXLFvqTzPLUOPyjNRgaUydccMsVzpw1IHJRwzRPKcMDh8sYdjhvJgBjAbs3s4wTl8Lm0xCHEd+PrC/PdyWGh6l2ZpFJ9bDUTXL8ugAPfZekEd+DtNdv+wfFmDOzexrMQG6BoyOrLTCDEZAVurpE4izGRjFvsDI9hWlRpusEJIz+bFKysPVvIpeSpI0Ph2u5GGIE9cYpqCsltGqS0dgOLSvvjAQMxutrZM8OpqDdinEuO7Jt+ufqT9RqQB4INX6gNKQBwLReigCSABFYl7MW++LVrYpKBtyubCJwIipWjUAsNR8z0ljpqCdkWjyjkFrm2fGkXC/QdjKLIfIerw7BgKFSJEOp8dQ6H2ghR4nh/DZ8EDNwCFf3YMiahPAOIdnh9DkYeoE4ZimAqbPztjiIoX0NDbwmDUvZohWfcmk8EofPeTHTEk/jaYTJYaATN0L3ig2oQ49IisRqeqsxOGjO5bNftqikIjS50bLWvQliflDF0wZPhYWa2uRG3I0C8NhaC6ih0wZKSs6FwqFZswE6yxhpwfP6hQ7IAhb4ephWJDhhWfZMp/x/YZUu7rahSiNmRYbRLjy990Gb7+4eMfP35qwLByrjQa3YTnUMcd87nowBMnbfQYfvrT5y9fydcv3/5szNDnEmY6nclChhr6MD+Ki6HoF7QYfv9c/EKRfiF/eTVjiMva/6e5ju0l1Id6qTVEjxYfl8jRYfj6OWYHoJ+MGJa5LN3bDIU2ja5discHqVbuax2GfyWshEaBHcfwaEdHSPMlhXaptm/B6N41eTouog7Dv3EEmbI2q8Iw3Mck9C+ZEPoWBv7hoXPwaD3pMPy7xzEUdkHLGO7FRv+D/hsK/UMTHx+/WagPh2XXYfiNZ6jTnHxk+JaXX8UG3pTQxzeK05BdgPQYvNJg+Pp7haFG+LFkWKiKFTNxF4VxGrNY29t9FIdtqsPwC89QJ8B6YLgLYPfnRv6wMNZmGC/FU/4lTBmarCEpzpRhw744y2AY8y7uhDgY+Trn8B8Vhi/qXzgwLNbjwSzUKakUNsxbMNQ/7mwdhv/ktQXWSDceGPrmbW2SvIVp7qlIYRms4b8qGl/jto49Q/bB/FIJSe7JOH8Yrq4+MG2Gn0JO0Ii/sZBhboAZN7lI8ofGOeD8MB3eQsfy/gmVS6iTUN0/Oxc0xplNSQ7YOHGRn+dnos+wX55CLWdrzxA/roybXCR5fPNaDPKw1t+lV1ePdM/Q0/np4/6YmRcUysqEzRMXRF/jF/i3vsl2xSlb89i3pJ4GUBOlyXCvMIRmsZyhOaQ1Uc0zF5oM9+6F4RqaQ1rX1rw2UcvH//7z0Tv8j040qjlDaW1i8/pSNcOPv3z+4pV229dv/1WSbM5QfgtI4xphFcPXn78wj7dL818Jf22LYU3Dc+M6bwXD198QT29P0v9fSwxr6rwb1+orGP4iIKi2bBozrKnVb9xvUc/w0+9CggzVd143ZljTb9G4tK2e4XcsJJgvYisMa+/iaVqAqVjDUEwQ1V+B0JRhbd+T2DTdzQqtvaNacQ7TEAkIEsXVmHKG7PBGwheq7V0TGW6EZjfB09NjbzNisuubVdricRHuRq6Wy0doOFVUbEoYMhLOr5+Dp8lTsFmE782w+v7D99sU4QfuRSYPc2EzhFrjr5bbNQr3oHH2oC7sFzJEdP3M6fPh9l3jgqKH9DTgRj6cLnmUvS/F0LVL+8NJjtuV3i2HAoYovD8NE05OA8WqYt5qnlQolp4W775bN9UmjI4E5li/GkFT3htR6cdnnvhrB97J9u+EIV6LJdNtJTahzvnwApPcyH7qZKZVF7UYVJrM4XO76jsVKk6iL+9jiioTm9tnSObyd+GLTzTuxeDvNhFG//e4W3OfonWGfl0WgGeok3rlZE01z9i/jQZJkgyi/UNGuDOGh1kWt9GSf4M9uBoLnftpKuHXY53XcHC9Lial7/onKZotC5FcbuiWGe5yAMObBaF4/wZkMQ0OWuGZkzR6lyfyhTI0ew6C5XRenSVeDAnPFdNDZwx7hRrmT35u82G6TpdBb8PPHtC8O7HSU4WIpHEV0fvyILbMkMUzkSnF3r2bbn+ZZjCDL1lq+Rxq5n+1b04096HOpApa/+JE47bx82Cof2+i+SKeB0ODuy+Nw4pn0dlldOO1aYuqJKsMg2m3oFmjrundifWRg0YwTfaZ3SNsnFeWeyGNYXpxsuFd0KZxRc2kpwkMO/JN7/M2ztJoeC1mME31Gd/JbnyvvukmUcD0mDQZGWSqMZoOCrFCsNGsGeP5FhYHEhqPW2z2eY1nlOB4aWMa8V0SG1f2NLOpzGdqMOwv0hsY0oVvPMqu6ZyZRnNYGIGiQR66uQgAzXvqDs3nPdm7/KtVQGZ2gccVdALQ3DXY7LxuAJudBx0Z1AGg8w+BMyzbB3yGJXQOacuwMYcUOku2VViZJQueB9wiLM0Dhs90bg22ZjrD53K3BHtzuW3MVm8BNmerN3DY2odFd/Q8KdomWMzZdM2pgpMZn1ZwVmfR7hk8YHA2elGvq6gBgjOhyOzpwVNMRDcodQ6ELVkyIgzH7j0NMrZ72+0J+plrfxFnNiKWdUjditTQdn5EgB7wsm0IGAWGLPRwG7s6jCQGBZ0MsHWiNlgIiIuaIiDdLyMhrWlBEfr3HS8jC+/blqGniIwTRBDg2G4CVg8peEqDLhDtQEeIMMw6URyMZq1aMbWIxn7bHJk/drFBSyy9VsOpDHu2RxKYI2Gtccyf3Iqna4wkboUjw/F58CuwHFuXq4iO3e9PHtEstDDG6ABGwplb+SLCMEW+nYXMn5O60w+1CGYh+EQyTGedGqCGuEsWwuuwdVcP00VifxiIZaySrNp/ort4Ob0ssV+J2wr6wTammOivJSKYxtuga+8BhmEvzfBbB7h8PdlbVzbO0t6ZihYVVlEyzeaEFj1hhKAShBT9WZTMs2kS/SA7sw53k2iQbNLt/WiWYzS636abZBBNzl6mXHDBBRdccMEFPwr+D5PO7cS4uSdZAAAAAElFTkSuQmCC"
                                width="28" height="26" className="d-inline-block align-top"/>Password</Form.Label>
                            <Form.Control type="password" placeholder="Enter Password" onChange={passwordinputvalchange}/>
                        </Form.Group>

                        <Form.Group controlId="formBasicCheckbox" style={{marginRight:"190px"}}>
                            <Form.Check type="checkbox" label="Check me out" style={{marginRight:"10px"}}/>
                        </Form.Group>
                        <Button variant="primary" type="submit" block onClick={onSubmit}>Submit</Button>
                    </Form>

                </Card.Body>
            </Card>
            </center>
        </div>
    )
}

export default Adminlogin;