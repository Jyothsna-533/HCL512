import React, { Fragment, useState ,useEffect} from 'react';
import { Container, Card } from 'react-bootstrap';
import {useHistory,useParams, Link} from 'react-router-dom';
import Adminaxios from './adminaxios';
import axios from 'axios';

const Edituser =()=>{

    const [user, setUser] = useState({
        name: ' ',
        username: ' ',
        email: ' ',
        phone: ' ',

    });

    const history=useHistory();
    const {id}=useParams();

    const{name,username,email,phone} = user;

    const onInputChange= e =>
    {
        setUser({...user,[e.target.name] : e.target.value})
        console.log(e.target.value);
    }
    useEffect(() =>{
        loadUser();

    },[]);

    const onSubmit= async e =>{
        e.preventDefault();
        await axios.put(`http://localhost:3003/users/${id}`,user);
        history.push("/adminaxios");

    }

    const loadUser= async() =>{
        const result=await axios.get(`http://localhost:3003/users/${id}`);
       setUser(result.data);
    }
    return (
        <center>
        <div style={{backgroundColor:'whitesmoke',backgroundImage:'url("data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBxAQDg0QEA8NDxANDQ0PDQ0NDQ8NDQ8NFREWFhURFRUYHSggGBolGxUVITEhJSkrLi4uFx8zODMtNygtLisBCgoKDg0OFxAQFy0dHR0rLS0tLSsrKy0rKy0tLS0tLS0rKy0tLS0tKy0tLSstLS0rLS0rLSsrLSstLS0tLS03Lf/AABEIALcBEwMBIgACEQEDEQH/xAAbAAADAQEBAQEAAAAAAAAAAAAAAQIDBAUHBv/EADIQAAICAQIFAwMDAgcBAAAAAAABAhEDBCExQVFhcRKRoROBsSIy0cHhFEJScoLw8QX/xAAaAQADAQEBAQAAAAAAAAAAAAAAAQIDBQQG/8QAHhEBAQEBAAIDAQEAAAAAAAAAAAECERIhAzFRQSL/2gAMAwEAAhEDEQA/AMBNkQlaXgZ13zZ2IGzOUw4XVSmZp7/cmxFSJtdIAmAyABYgTaBAMaTTLRFC9aXNAVjQTZH1L4Etj4xtVKZIAUi1US4Ta/giIxB1wkmXRxRk07R2Ycql56fwTY0zZVJFJFUOietOJSKhBt0t2aYsLk9uHNnfiwqK2+76ka1xpj4+ssGnUd3u/heDdItIaiZW9eiZkKDadptPqtj0NPr+U1/yX9UcaiOibOtc6ufp7cGmrTtdivSeLjz+l2pV8o9HR65TdVulx5My1ix6cfJL6/rqoAAhqBDoQDj5Zpns+zNJSo4Vn9D/ANwPU9vk6Xi5HXTKVk2c/wDiH0F9d9EVxPXRYjD6z6IPrPoh8J343sh2cOLVcnS6M2cn1F4ptbtkvIjEB8Jp9XsS8rJAC6G2IYhlThOjc50jTHLl7FMa0AAElURiiMQAIAAOvT6i9pfZ/wAno4NPe72XyzxYxPSw5Wkuey2Znqfjf49fr1VKK2TXhB9Vdzjx5k+3ngbpGFnHrmu/TX63RB9V/wDUQkNISvZ+pvmwoaQ0hHwkjs/+f+6Xj+pzJHVoeMvBOvppif6j1sU7XdcS6OOEqdnZGVq1zMbHtzemAAJT4tqnuvcqErRnqH+rwkLE/k638cStgAAABgTJjhWpN8Oatnw69DFIZSHaM5sWSvB0JkWAwAAICGA4mgABFIawlZRkmaJkpsXEYojEQLjEFEoADrxftXg5Dr0/7V9ydNMfbQvHlceD26PgQNIhtPTsxahPjs+/A6EjzDTFllHg/s90Z3H41z8n69FIpI58WqT47PryOuK/9M7OPRmy/RKJ06RbvwYpG+mW78EVrie3QzTT5KdPg/hmTIbIbd49MDijqJJJbOuoE8X5x8fy/ufkQPi/I0jrOM1hK0UZxdGgjBI2IqI1QNAkMaQVjm1/BNFAHTF2M5oyo3jKybCUAAOJ0BgAJBUGCiylEQ40iaRiVpsdp77p/BUoNf2EXikAACB1ab9v3ZynTpOD8k6+l4+24woZDcJAA0hGEjTHlceDrtyJSLWJ+BXn9VJf47MGtT2kq7rdHoadp7ppquKPHjgXM6tIqdLmjDcn8en49a77elKaIczNFIzejp2wKUWAh7fJkNMQ4nWcpRpFmZpjjz9hcHlwUMChp6kaQwAdADQxF1NDVoaRSQdLybQTastRNYQpJdPyJxF0rEUUkCQwIACQxBvpJVKuqOo4cbpp9GdrZNVEygmZyxmoglFkYNHTo/8AN9iGdWhwcZO6eyQtX0MZ/wBKKjBvkdCglyLSMbp6ZhjHB1fsWsS8+TQaRPlWkzCSKSHQE9XwFY3uvIqGhKkdo0KO9GmNbmdbRqkAwJavkBQkijruKcI2zdEwjSLQmdpNCLoloDhDSBIYC0AkCQxJBvpob30/JkdmKNJfIqcWNIcUVRKkShZFG4ONj6VjAaRUoUNIZBI6sbtI5jbC9mKiLYASxGvDj9Ukvfsj1YxpJLkY6TD6Y2+L4+OhuY7va3xnkBSQolGbaBIoENISyHQx0JUFDHRSiI2+F7I6MSObDzOuKpGdbYMB0Amr5EXijz9iYq2bpHWrhWmMENCQEOURopAbEEi5xpiAgNANAa8ELa6Lc7UjLTwpeTdE1QHQIZICRQJDSGYoiUOhoNIXRzrBIvG9y5Qszqiup5xq2b6PD6nb4R+WYQi20lxZ6uLH6YpLl8sz3ri8Z7erAAMXoOJojI1iTV5NDAYlCikgSKSEoJFIEaYsTk6X3fQSpOq08bf5OouGNJUg9Jnb2vRnPIQAAKfJ8caXktGnoQKB1evn/JA0V6Bxg+gEEXFCSKEZSjZlR0IjJHn7hKbNIvHG2l7+BHTpYbX1/A6bZIoBogwUkJFIQFDAaQKCQ0gSN8enk+VedhW8ORkP6fq2q/B249Klx3+EdEYpcEl4M7tcx+uXSaZx3fHguyOk1gDx32Iuu1rMcnpkA5RaBCHOBF4yQTA42RSQIpIhqEikCNsGFy7LmxW8VJ0sOJyfbmzvhBJUgjFJUuAzO3r05z4gAGTVEBVCJD5YNCRSOw+bCRtCNChGixGGhfTRRSQlRk8bFR0BQuhxKG9HdFUqNcOmT3d9jdYI9PkV20mbXKhnYsa6L2LUV0RPkrwccY9n7FrHLo/wdaQxXZ+LkWCXT5R0w0XD1PirpFxjbS6tI9KUU0RrdjTHxyuPHijHgvvzLKnChInvV84BpAhiOLgWRjNCa0gFLEn2LSKSA+OWUGv55EnbRE8CfDZ/A/JNx+Iwvbwa0Yxi4tXwe18ju0+D1bvh+RavF4lvosGD1dl+Tuiq2QJAY29erOeAAASgMQxWgwABB8sNoRoUIlo675w0ADQjNFIEhipg30+K93w/JGHH6n2XE7EibV5yY0ICGq0NIUShWmAAaRIbaWP6l23O45tHHi/sdJnq+3p+OcyTVmMoUbiYT0dnWAxyjQJDTw4cTZIyhxRuhVeQkNAikhKCKiiseNvx1OmEEuBF0vOOs4YevsdKIKiRW0khgMaJUVBQwAFQUMAAEDEAfOZ42vBKOwiWFPhs/g6k04Fx+OYaHODXESKQ0KxwcnXuKMbaS5nbjgoqvd9SLeLznpwikqRQAQ1AUOhgfAi0QVHYVNSQwHFW66knHdp41Fe5oIDN6YBACBQJlEsYEyjxXk6UYOJ2YsLfZdRWnmIjG9kdOPBXHftyNIQS4f3KM7pvnHPsAAEtAVAkEwDUAAkwAAAAADAJAAAPwlFJAB0XEOrMJ6b/AE+wAHeDxldOHD6VvxfH+DQAEf0aQDADgBIAAzAAFQqJ0aeP6l23ACKvH27GxABD0wI0jjbACbTzOrWHuUsK7sYE9q/GKWNdEdEXsAE1plVhYAJZgAAAAAAaoAAkwAAAAmAACAAAP//Z")',backgroundSize:'cover',width:'1250px',height:'650px'}}>
            <h3 style={{backgroundColor:'lightsteelblue'}}>Edit User</h3><br/>
            
            <Link class='btn btn-outline-warning' to={'/adminaxios'} >Back to Adminaxios</Link>{' '}<br/><br/>
            <Card style={{ width: '22rem'}}>
                <form onSubmit={e => onSubmit(e)} style={{backgroundColor:'whitesmoke',paddingTop:'20px',paddingBottom:'20px',paddingLeft:'15px',paddingRight:'10px',backgroundImage:'url("data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBxEREhUTExIRFRIXFhIVFxYSFRUVFRIQGxcWFhUSFRYYHSggGBslHRcTITEiJykrLi4wFyAzODMtNygtLisBCgoKDg0OFw8QGi0mICUwNS0tLi0wKy0tLSstLSstKy0tLS03Nys3LS0tLS8tNS0tLS0rLS0rKy0tMSstLS0tN//AABEIAIcBdAMBIgACEQEDEQH/xAAaAAEAAwEBAQAAAAAAAAAAAAAAAgMEAQUG/8QAOhAAAgECAwUGAwcEAQUAAAAAAAECESEDMUEEElFhgSJxkaGxwTLR8BMUQlJikuEFgsLxciMzorLS/8QAGgEBAAMBAQEAAAAAAAAAAAAAAAEDBAIGBf/EACYRAQACAQQBBAIDAQAAAAAAAAABAhEDEiExQRMyUWEicYGh8AT/2gAMAwEAAhEDEQA/APkwAenedAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAOpVJYcHJ2729EuLLa0pTpxfN8O4Im3hDdSzzIqTOTlULLy+YMfK/CxU2k0nRS3atpZN0s7Xv/so3eOhPCw+NrPvpTgS+8tR3FTdqnVpOVuD07kHPU8O/az7lzovULaGvxJ/2r3RQ2dhBuyQNlfK2E04uKir3TdXJNaJ8+HcVTi06NNNZp2aNmBgqLTzefJFuPhpt1vw400uFfqxE4h5gNGJsz0vyeZQ1QLotE9OAAJAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAJQg26LMibMPCaSil2506R0XLiw5tbEOyw2koxTaren4no+7P1KMKEpOLo3WUYqmrtSK8izF3X2Y5Rybs5u1XybpbglQhCTSrlSvjai9+gcVzhCWHR0lZqz1v0LZKLitxOqXa3qVbq+1FcKUXGxTZ8vNfNeZfs8JKsk2qJpOL5XusreoTbrMq8CUr0rRp14OzpXjcju8VTql5MnDE3pKro6qr0fGq0Kpwas/rqEx2vwtmTVd5Z0oq73fwp8jRGKVlZGTZp0lydvkzYFOpnOJCU9O7+PYRjXu4iT4ZL6uQq8onJwTzR0BPTNLZeD8QaaglZ6lnmgANIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAADTsODvSq/hVK828l9cDZtk0m2rJ1aa/L3+Hkc2LBpFc6v0v5op23EpRLJ1rrvUpo7Uz8SGSZ36jE2atnlGVFOu7VNtfEoqzpx1zM+9HWP7XT1qX7QoRk9zecaRjWVE3ZOToufqSvtzwzypW1aVtXOmleZujGiotE/GjM+zYfa7vXQ1oK9W3UPP32+ff8y7asXtyokotp7t3HJXuVYUe1zXtf2NG04eGoQalKUqNTSVFGSySetvQLLTEWhnpF8uTy8fn4m/Cuk5W93y+fM89SX5V1q/SiL9kx2nStK8ElfTLquoc6lZmOGySb0otOHic3OLXr6EWzhDPhPs834L5jeWiXWrIAGE/tH9JAgAYh5oAJbgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAJ4MKyS4tcrEDRsS7VeFw5vOKzL28eUVCiVGqrvVVT1fkeLtmnX2N7k5b3dXpVGLa1Zd/16EQx/8APXbLIXbTnT6q/wCKFcVVpE5ren3teBLbPbXs8eyuOvdoTiq5HcNX7vCnMliPhl5t8yGKZzLFjPdc0vHjVp0XBUqVYT0eTt3PR/WjZbtiyfGnlVe6MxLXTmrrVPrUFk7re1sn7Pw9OZUHcPRhPeSfHPv1OlGwtUlvSUVSqqm6yX4VTVr0RP7xDi/AhktWd0xCwFX3mP6vBfM596jwl5A2W+FwKfvUeD8UCTZb4YwAGsAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAADXsas+hkNuyrs9Qr1fa0YTvyy6OxXjQqmtffQ6WyvfX218PTuIZc4nLy8PjyfyXqjTsmHV10SV+DpT2ZCeFRy0Vr6JN19jRDEjuRVHH4quVKN2o/BktGpbjhOUtFl9XYi9Hl9XFFxr3ZeI3uFiGdVt+E1FNrmucXquXZMB6m0NyVG2+zRVf8Ackup5ZLRoTO3ErtkjWai3RSai28km1fpn0LNq2RQlJRmpwi/jjk+lXRkcCFIuX9q/wAn0TS/uRU8ThVUy494dczbMS5KVe7TkRLd9P4l1jZ+GT8h9jX4Xvcl8X7flUO847VAE4LXh6hKVVG26m9a1tysCtnAjbAAAkAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAADbsr7PVmI27FFuNlrTyqFer7VpbhRfGmq415LU4qKyu+PyWpFVb1q/EhknlP+o4kXGKwlTJuq7TnSj3Xe2tFxPM3qp1zqnfwf+PgbdpwG8P7S15ytXtJpKzWipfoZMKVXSWtq63yrxJhfoxEU4Rw8Vxyy4aGnD2iLzs+eXiZp4TV1dcVp3rNdSEcwstStuXqYmZ58sJ726uNjixGm6PXp4Gn7aLjXdcZ3TknVSrlRaUVdeAcVraijaMStIr4Y2X6nesurb6UKSe5wo+7PwzO/Yy4Nd9l4uwWxiOFZ0n9mtZR6VfpbzHZ/U/CPzCcpLFcrNb3P8X7vnU7KCdFF15Ozb4rj/oKairRVXxq6LrbyORlOWVell1pYOfuOD7tP8k/2sFyw56yXVKXSrQDj1J+Y/tjAAXAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAep/ScXsTjalYSvwvGX+B5Zq/p0qTo8pJx6v4f/JREq9au6kw9rDmlRpvpZfM8/FxWoullR5W5dcyWHNxfsUSkpQlSlt1NNpPPTjkQxaenicscXRJ836ITXDJ3RN4fZzWa15P5E8HDTzaoss7y/LlrTyJbt0Ryli7LiRUcSlFNb0XVKvHX6qRhGLa3nFOq+Gr8qU80FLf7Ll/xpWkXwVaUT+RzZ1BSTlv7qarRJPuVa3DnnHPf0msCGjxJt6RSjfzfkcxqxe6oXWdU21LVNeCy0IYTcHvqqcX2eO+sn0s/DidxtqliNubbk3VyXHmsn5BERbPzH+/gSxODXct1exyktXHrKL9yqWHS9muKy/jqRCyI/S7djq0v+O8/KnuW7PssJV/6isq0a3XK9KRq7syAIms44l6McHDTq1KXe6Kvcl7lu+vyruvTwVDDhbS1Z3Xmvma8Nb2V19Z8CGa9Zj3NWDjxirxje+WmWvcwVYu6nS7pazSVVnS3GoCjZE8vHABL6YAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAHUzgA9VSUknxvXg9U+vsZMWFG1+ZvrZONOo2LF/A8ndcpfz7E9rbjTrVPjmGasTW+1nwb1jxp65+bJbTBx3ct1rei0803Sr4Oqy5Iv2TCjKSW8ob9YreyVuOlW0vEhJt4ahWNYyk12l8Mkt5X5pPqws3fkpcd6/7uXP6+ROfbpTTOv8A7v3G442t+q6v+nP6fcWYuzywoxnS2JXddn2V8SdNcl48QmbRmOf0ox5VpTKlF7vvefUqNDwG4Oai9xNX0i9Yt8cjOHVZjGISjJrL67yXZf6X5fwVgOsJTg1n/vuepEnCbXdweRp+yw1huTbWIpJLDpbda+JvTW2fiHM229s0Yauy9eS4luDitNUtFXazqle/EplJvMlDJvuXjf28wTGY5aY7UnnVPlcGIBz6VQABYAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA6ejgtYsdx/9y7T0dPwv5gBVrx+O7zDFjVTS1il/9erL8PDTnXepWlKpusm8rcLvoAETP4xP0z42E4u97u/Hne5yEtHl6PigA7pO6sTK6ONKEXFN0cnvRraVEs1rmyqVK3XVfL/QAKxHbjw7VV1xIABNZzlauzfXNclxOYV6rin4rte3mADxlWWSyS737ewATPhWAAl//9k=")'}}>
                <div className='form-group' >
                    <p style={{marginRight:'250px',color:'white'}}>Name</p>
                    <input type='text' className='form-control'
                        placeholder='Enter Your Name' name='name' value={name} onChange={e => onInputChange(e)}/>
                </div>

                <div className='form-group'>
                    <p style={{marginRight:'230px',color:'white'}}>Username</p>
                    <input type='text' className='form-control '
                        placeholder='Enter Your User Name' name='username' value={username} onChange={e => onInputChange(e)}/>
                </div>

                <div className='form-group'>
                    <p style={{marginRight:'250px',color:'white'}}>Email</p>
                    <input type='text' className='form-control'
                        placeholder='Enter Your Email' name='email' value={email} onChange={e => onInputChange(e)}/>
                </div>

                <div className='form-group'>
                    <p style={{marginRight:'180px',color:'white'}}>Mobile Number</p>
                    <input type='text' className='form-control '
                        placeholder='Enter Your Number' name='phone' value={phone} onChange={e => onInputChange(e)}/>
                </div>
        
                <button className='btn btn-warning btn-block'>Update User</button>
                </form>
            </Card>
            </div>
            </center>
           
     
    )
}

export default Edituser;