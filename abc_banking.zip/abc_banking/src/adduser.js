import React, { Fragment, useState } from 'react';
import { Container, Card, Form, Button } from 'react-bootstrap';
import { useHistory } from 'react-router-dom';
import Adminaxios from './adminaxios';
import './style.css';
import axios from 'axios';


const Adduser = () => {


    const [user, setUser] = useState({
        name: '',
        username: '',
        email: ' ',
        phone: ' ',
        aadhar: null,
        balance: null,
        password: '',
        currentBalence: null,
        transaction:[],
        role:''


    });

    const history = useHistory();

    const { name, username, email, phone, aadhar, balance, currentBalence, password,transaction ,role} = user;

    const onInputChange = e => {
        setUser({ ...user, [e.target.name]: e.target.value })
        console.log(e.target.value);
    }

    const onSubmit = async e => {
        e.preventDefault();
        await axios.post("http://localhost:3003/users", user);
        history.push("/adminaxios")

    }
    return (
       <div style={{backgroundColor:'whitesmoke',backgroundImage:'url("data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBxAQDg0QEA8NDxANDQ0PDQ0NDQ8NDQ8NFREWFhURFRUYHSggGBolGxUVITEhJSkrLi4uFx8zODMtNygtLisBCgoKDg0OFxAQFy0dHR0rLS0tLSsrKy0rKy0tLS0tLS0rKy0tLS0tKy0tLSstLS0rLS0rLSsrLSstLS0tLS03Lf/AABEIALcBEwMBIgACEQEDEQH/xAAbAAADAQEBAQEAAAAAAAAAAAAAAQIDBAUHBv/EADIQAAICAQIFAwMDAgcBAAAAAAABAhEDBCExQVFhcRKRoROBsSIy0cHhFEJScoLw8QX/xAAaAQADAQEBAQAAAAAAAAAAAAAAAQIDBQQG/8QAHhEBAQEBAAIDAQEAAAAAAAAAAAECERIhAzFRQSL/2gAMAwEAAhEDEQA/AMBNkQlaXgZ13zZ2IGzOUw4XVSmZp7/cmxFSJtdIAmAyABYgTaBAMaTTLRFC9aXNAVjQTZH1L4Etj4xtVKZIAUi1US4Ta/giIxB1wkmXRxRk07R2Ycql56fwTY0zZVJFJFUOietOJSKhBt0t2aYsLk9uHNnfiwqK2+76ka1xpj4+ssGnUd3u/heDdItIaiZW9eiZkKDadptPqtj0NPr+U1/yX9UcaiOibOtc6ufp7cGmrTtdivSeLjz+l2pV8o9HR65TdVulx5My1ix6cfJL6/rqoAAhqBDoQDj5Zpns+zNJSo4Vn9D/ANwPU9vk6Xi5HXTKVk2c/wDiH0F9d9EVxPXRYjD6z6IPrPoh8J343sh2cOLVcnS6M2cn1F4ptbtkvIjEB8Jp9XsS8rJAC6G2IYhlThOjc50jTHLl7FMa0AAElURiiMQAIAAOvT6i9pfZ/wAno4NPe72XyzxYxPSw5Wkuey2Znqfjf49fr1VKK2TXhB9Vdzjx5k+3ngbpGFnHrmu/TX63RB9V/wDUQkNISvZ+pvmwoaQ0hHwkjs/+f+6Xj+pzJHVoeMvBOvppif6j1sU7XdcS6OOEqdnZGVq1zMbHtzemAAJT4tqnuvcqErRnqH+rwkLE/k638cStgAAABgTJjhWpN8Oatnw69DFIZSHaM5sWSvB0JkWAwAAICGA4mgABFIawlZRkmaJkpsXEYojEQLjEFEoADrxftXg5Dr0/7V9ydNMfbQvHlceD26PgQNIhtPTsxahPjs+/A6EjzDTFllHg/s90Z3H41z8n69FIpI58WqT47PryOuK/9M7OPRmy/RKJ06RbvwYpG+mW78EVrie3QzTT5KdPg/hmTIbIbd49MDijqJJJbOuoE8X5x8fy/ufkQPi/I0jrOM1hK0UZxdGgjBI2IqI1QNAkMaQVjm1/BNFAHTF2M5oyo3jKybCUAAOJ0BgAJBUGCiylEQ40iaRiVpsdp77p/BUoNf2EXikAACB1ab9v3ZynTpOD8k6+l4+24woZDcJAA0hGEjTHlceDrtyJSLWJ+BXn9VJf47MGtT2kq7rdHoadp7ppquKPHjgXM6tIqdLmjDcn8en49a77elKaIczNFIzejp2wKUWAh7fJkNMQ4nWcpRpFmZpjjz9hcHlwUMChp6kaQwAdADQxF1NDVoaRSQdLybQTastRNYQpJdPyJxF0rEUUkCQwIACQxBvpJVKuqOo4cbpp9GdrZNVEygmZyxmoglFkYNHTo/8AN9iGdWhwcZO6eyQtX0MZ/wBKKjBvkdCglyLSMbp6ZhjHB1fsWsS8+TQaRPlWkzCSKSHQE9XwFY3uvIqGhKkdo0KO9GmNbmdbRqkAwJavkBQkijruKcI2zdEwjSLQmdpNCLoloDhDSBIYC0AkCQxJBvpob30/JkdmKNJfIqcWNIcUVRKkShZFG4ONj6VjAaRUoUNIZBI6sbtI5jbC9mKiLYASxGvDj9Ukvfsj1YxpJLkY6TD6Y2+L4+OhuY7va3xnkBSQolGbaBIoENISyHQx0JUFDHRSiI2+F7I6MSObDzOuKpGdbYMB0Amr5EXijz9iYq2bpHWrhWmMENCQEOURopAbEEi5xpiAgNANAa8ELa6Lc7UjLTwpeTdE1QHQIZICRQJDSGYoiUOhoNIXRzrBIvG9y5Qszqiup5xq2b6PD6nb4R+WYQi20lxZ6uLH6YpLl8sz3ri8Z7erAAMXoOJojI1iTV5NDAYlCikgSKSEoJFIEaYsTk6X3fQSpOq08bf5OouGNJUg9Jnb2vRnPIQAAKfJ8caXktGnoQKB1evn/JA0V6Bxg+gEEXFCSKEZSjZlR0IjJHn7hKbNIvHG2l7+BHTpYbX1/A6bZIoBogwUkJFIQFDAaQKCQ0gSN8enk+VedhW8ORkP6fq2q/B249Klx3+EdEYpcEl4M7tcx+uXSaZx3fHguyOk1gDx32Iuu1rMcnpkA5RaBCHOBF4yQTA42RSQIpIhqEikCNsGFy7LmxW8VJ0sOJyfbmzvhBJUgjFJUuAzO3r05z4gAGTVEBVCJD5YNCRSOw+bCRtCNChGixGGhfTRRSQlRk8bFR0BQuhxKG9HdFUqNcOmT3d9jdYI9PkV20mbXKhnYsa6L2LUV0RPkrwccY9n7FrHLo/wdaQxXZ+LkWCXT5R0w0XD1PirpFxjbS6tI9KUU0RrdjTHxyuPHijHgvvzLKnChInvV84BpAhiOLgWRjNCa0gFLEn2LSKSA+OWUGv55EnbRE8CfDZ/A/JNx+Iwvbwa0Yxi4tXwe18ju0+D1bvh+RavF4lvosGD1dl+Tuiq2QJAY29erOeAAASgMQxWgwABB8sNoRoUIlo675w0ADQjNFIEhipg30+K93w/JGHH6n2XE7EibV5yY0ICGq0NIUShWmAAaRIbaWP6l23O45tHHi/sdJnq+3p+OcyTVmMoUbiYT0dnWAxyjQJDTw4cTZIyhxRuhVeQkNAikhKCKiiseNvx1OmEEuBF0vOOs4YevsdKIKiRW0khgMaJUVBQwAFQUMAAEDEAfOZ42vBKOwiWFPhs/g6k04Fx+OYaHODXESKQ0KxwcnXuKMbaS5nbjgoqvd9SLeLznpwikqRQAQ1AUOhgfAi0QVHYVNSQwHFW66knHdp41Fe5oIDN6YBACBQJlEsYEyjxXk6UYOJ2YsLfZdRWnmIjG9kdOPBXHftyNIQS4f3KM7pvnHPsAAEtAVAkEwDUAAkwAAAAADAJAAAPwlFJAB0XEOrMJ6b/AE+wAHeDxldOHD6VvxfH+DQAEf0aQDADgBIAAzAAFQqJ0aeP6l23ACKvH27GxABD0wI0jjbACbTzOrWHuUsK7sYE9q/GKWNdEdEXsAE1plVhYAJZgAAAAAAaoAAkwAAAAmAACAAAP//Z")',backgroundSize:'cover',width:'1250px',height:'650px'}}>

<center>
    <h3 style={{backgroundColor:'lightsteelblue'}}>Add User</h3><br/>
            <Card className="addusercard" style={{ width: '22rem',border:'2px solid black'}}>
                {/* <Card.Title className="t1"><h2><small>Add User</small></h2></Card.Title><br></br> */}
                <Form onSubmit={e => onSubmit(e)} className='adduserform'style={{backgroundImage:'url("https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRIFW72RtWe-BdWcbrtDQOjZphDKImRwYny2w&usqp=CAU")'}}>
                    <Form.Group controlId="formBasicName">
                        <Form.Label  style={{marginRight:'250px',color:'white'}}>Name</Form.Label>
                        <Form.Control type="text" placeholder="Enter Name" name='name' value={name} onChange={e => onInputChange(e)} />

                    </Form.Group>

                    <Form.Group controlId="formBasicUsername">
                        <Form.Label style={{marginRight:'220px',color:'white'}}>Username</Form.Label>
                        <Form.Control type="text" placeholder="Enter Username" name='username' value={username} onChange={e => onInputChange(e)} />
                    </Form.Group>

                    <Form.Group controlId="formBasicEmail">
                        <Form.Label style={{marginRight:'250px',color:'white'}}>Email</Form.Label>
                        <Form.Control type="email" placeholder="Enter Email" name='email' value={email} onChange={e => onInputChange(e)} />
                    </Form.Group>

                    <Form.Group controlId="formBasicPassword">
                        <Form.Label style={{marginRight:'220px',color:'white'}}>Password</Form.Label>
                        <Form.Control type="password" placeholder="Enter Password" name='password' value={password} onChange={e => onInputChange(e)} />
                    </Form.Group>

                    <Form.Group controlId="formBasicMobile">
                        <Form.Label style={{marginRight:'180px',color:'white'}}>Mobile Number</Form.Label>
                        <Form.Control type="number" placeholder="Enter Mobile Number" name='phone' value={phone} onChange={e => onInputChange(e)} />

                    </Form.Group>
                    <Form.Group controlId="formBasicAdhar">
                        <Form.Label style={{marginRight:'180px',color:'white'}}>Aadhar Number</Form.Label>
                        <Form.Control type="number" placeholder="Enter Adhar Number" name='AdharNO' value={aadhar} onChange={e => onInputChange(e)} />

                    </Form.Group>

                    <Form.Group controlId="formBasicPassword">
                        <Form.Label style={{marginRight:'260px',color:'white'}}>Role</Form.Label>
                        <Form.Control type="text" placeholder="Enter Role" name='role' value={role} onChange={e => onInputChange(e)} />

                    </Form.Group>

                    <Button variant="warning" type="submit" block>Add User</Button>
                </Form>

            </Card>

            </center>
            </div>
    )
}
export default Adduser;

