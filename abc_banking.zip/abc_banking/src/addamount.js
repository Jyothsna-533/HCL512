import React, { Fragment, useState, useEffect } from 'react';
import { Navbar, Button, Card, Form, Row, Col } from 'react-bootstrap';
import axios from 'axios';
import { useParams, Link } from 'react-router-dom';
 
function AddAmount() {
    const [user, setUser] = useState({
        id: '',
        name: ' ',
        username: ' ',
        email: ' ',
        phone: ' ',
        website: ' ',
        balance: 0,
        transaction: []
 
    });
    const [amount, setAmount] = useState('');
 
    const { id } = useParams();
    useEffect(() => {
        const res = sessionStorage.getItem('user');
        let user = JSON.parse(res);
        getUser(user.id);
    }, []);
 
    const getUser = async (id) => {
        const res = await axios.get(`http://localhost:3003/users/${id}`);
        setUser(res.data);
    }

    const onSubmit = async e => {
        e.preventDefault();
        let date = new Date;
        let obj= {
            "type": '',
            "accountType": '',
            "dateTime": date,
            "amount":0
        };
        obj.amount = amount;
        if(parseInt(amount) > 0){
            obj.type = "Credit";
        }else {
            obj.type = "Debit";
        }
        obj.accountType = "Savings";
        user.transaction.push(obj);
        user.balance = parseInt(user.balance) + parseInt(amount);
        await axios.put(`http://localhost:3003/users/${user.id}`, user);
        getUser(user.id);
        alert('Amount added successfully');
 
    }
    const passwordinputvalchange = (e) => {
        setAmount(e.target.value);
 
    }
    return (
        <div style={{backgroundImage:'url("data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBxEREhUTExIRFRIXFhIVFxYSFRUVFRIQGxcWFhUSFRYYHSggGBslHRcTITEiJykrLi4wFyAzODMtNygtLisBCgoKDg0OFw8QGi0mICUwNS0tLi0wKy0tLSstLSstKy0tLS03Nys3LS0tLS8tNS0tLS0rLS0rKy0tMSstLS0tN//AABEIAIcBdAMBIgACEQEDEQH/xAAaAAEAAwEBAQAAAAAAAAAAAAAAAgMEAQUG/8QAOhAAAgECAwUGAwcEAQUAAAAAAAECESEDMUEEElFhgSJxkaGxwTLR8BMUQlJikuEFgsLxciMzorLS/8QAGgEBAAMBAQEAAAAAAAAAAAAAAAEDBAIGBf/EACYRAQACAQQBBAIDAQAAAAAAAAABAhEDEiExQRMyUWEicYGh8AT/2gAMAwEAAhEDEQA/APkwAenedAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAOpVJYcHJ2729EuLLa0pTpxfN8O4Im3hDdSzzIqTOTlULLy+YMfK/CxU2k0nRS3atpZN0s7Xv/so3eOhPCw+NrPvpTgS+8tR3FTdqnVpOVuD07kHPU8O/az7lzovULaGvxJ/2r3RQ2dhBuyQNlfK2E04uKir3TdXJNaJ8+HcVTi06NNNZp2aNmBgqLTzefJFuPhpt1vw400uFfqxE4h5gNGJsz0vyeZQ1QLotE9OAAJAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAJQg26LMibMPCaSil2506R0XLiw5tbEOyw2koxTaren4no+7P1KMKEpOLo3WUYqmrtSK8izF3X2Y5Rybs5u1XybpbglQhCTSrlSvjai9+gcVzhCWHR0lZqz1v0LZKLitxOqXa3qVbq+1FcKUXGxTZ8vNfNeZfs8JKsk2qJpOL5XusreoTbrMq8CUr0rRp14OzpXjcju8VTql5MnDE3pKro6qr0fGq0Kpwas/rqEx2vwtmTVd5Z0oq73fwp8jRGKVlZGTZp0lydvkzYFOpnOJCU9O7+PYRjXu4iT4ZL6uQq8onJwTzR0BPTNLZeD8QaaglZ6lnmgANIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAADTsODvSq/hVK828l9cDZtk0m2rJ1aa/L3+Hkc2LBpFc6v0v5op23EpRLJ1rrvUpo7Uz8SGSZ36jE2atnlGVFOu7VNtfEoqzpx1zM+9HWP7XT1qX7QoRk9zecaRjWVE3ZOToufqSvtzwzypW1aVtXOmleZujGiotE/GjM+zYfa7vXQ1oK9W3UPP32+ff8y7asXtyokotp7t3HJXuVYUe1zXtf2NG04eGoQalKUqNTSVFGSySetvQLLTEWhnpF8uTy8fn4m/Cuk5W93y+fM89SX5V1q/SiL9kx2nStK8ElfTLquoc6lZmOGySb0otOHic3OLXr6EWzhDPhPs834L5jeWiXWrIAGE/tH9JAgAYh5oAJbgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAJ4MKyS4tcrEDRsS7VeFw5vOKzL28eUVCiVGqrvVVT1fkeLtmnX2N7k5b3dXpVGLa1Zd/16EQx/8APXbLIXbTnT6q/wCKFcVVpE5ren3teBLbPbXs8eyuOvdoTiq5HcNX7vCnMliPhl5t8yGKZzLFjPdc0vHjVp0XBUqVYT0eTt3PR/WjZbtiyfGnlVe6MxLXTmrrVPrUFk7re1sn7Pw9OZUHcPRhPeSfHPv1OlGwtUlvSUVSqqm6yX4VTVr0RP7xDi/AhktWd0xCwFX3mP6vBfM596jwl5A2W+FwKfvUeD8UCTZb4YwAGsAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAADXsas+hkNuyrs9Qr1fa0YTvyy6OxXjQqmtffQ6WyvfX218PTuIZc4nLy8PjyfyXqjTsmHV10SV+DpT2ZCeFRy0Vr6JN19jRDEjuRVHH4quVKN2o/BktGpbjhOUtFl9XYi9Hl9XFFxr3ZeI3uFiGdVt+E1FNrmucXquXZMB6m0NyVG2+zRVf8Ackup5ZLRoTO3ErtkjWai3RSai28km1fpn0LNq2RQlJRmpwi/jjk+lXRkcCFIuX9q/wAn0TS/uRU8ThVUy494dczbMS5KVe7TkRLd9P4l1jZ+GT8h9jX4Xvcl8X7flUO847VAE4LXh6hKVVG26m9a1tysCtnAjbAAAkAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAADbsr7PVmI27FFuNlrTyqFer7VpbhRfGmq415LU4qKyu+PyWpFVb1q/EhknlP+o4kXGKwlTJuq7TnSj3Xe2tFxPM3qp1zqnfwf+PgbdpwG8P7S15ytXtJpKzWipfoZMKVXSWtq63yrxJhfoxEU4Rw8Vxyy4aGnD2iLzs+eXiZp4TV1dcVp3rNdSEcwstStuXqYmZ58sJ726uNjixGm6PXp4Gn7aLjXdcZ3TknVSrlRaUVdeAcVraijaMStIr4Y2X6nesurb6UKSe5wo+7PwzO/Yy4Nd9l4uwWxiOFZ0n9mtZR6VfpbzHZ/U/CPzCcpLFcrNb3P8X7vnU7KCdFF15Ozb4rj/oKairRVXxq6LrbyORlOWVell1pYOfuOD7tP8k/2sFyw56yXVKXSrQDj1J+Y/tjAAXAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAep/ScXsTjalYSvwvGX+B5Zq/p0qTo8pJx6v4f/JREq9au6kw9rDmlRpvpZfM8/FxWoullR5W5dcyWHNxfsUSkpQlSlt1NNpPPTjkQxaenicscXRJ836ITXDJ3RN4fZzWa15P5E8HDTzaoss7y/LlrTyJbt0Ryli7LiRUcSlFNb0XVKvHX6qRhGLa3nFOq+Gr8qU80FLf7Ll/xpWkXwVaUT+RzZ1BSTlv7qarRJPuVa3DnnHPf0msCGjxJt6RSjfzfkcxqxe6oXWdU21LVNeCy0IYTcHvqqcX2eO+sn0s/DidxtqliNubbk3VyXHmsn5BERbPzH+/gSxODXct1exyktXHrKL9yqWHS9muKy/jqRCyI/S7djq0v+O8/KnuW7PssJV/6isq0a3XK9KRq7syAIms44l6McHDTq1KXe6Kvcl7lu+vyruvTwVDDhbS1Z3Xmvma8Nb2V19Z8CGa9Zj3NWDjxirxje+WmWvcwVYu6nS7pazSVVnS3GoCjZE8vHABL6YAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAHUzgA9VSUknxvXg9U+vsZMWFG1+ZvrZONOo2LF/A8ndcpfz7E9rbjTrVPjmGasTW+1nwb1jxp65+bJbTBx3ct1rei0803Sr4Oqy5Iv2TCjKSW8ob9YreyVuOlW0vEhJt4ahWNYyk12l8Mkt5X5pPqws3fkpcd6/7uXP6+ROfbpTTOv8A7v3G442t+q6v+nP6fcWYuzywoxnS2JXddn2V8SdNcl48QmbRmOf0ox5VpTKlF7vvefUqNDwG4Oai9xNX0i9Yt8cjOHVZjGISjJrL67yXZf6X5fwVgOsJTg1n/vuepEnCbXdweRp+yw1huTbWIpJLDpbda+JvTW2fiHM229s0Yauy9eS4luDitNUtFXazqle/EplJvMlDJvuXjf28wTGY5aY7UnnVPlcGIBz6VQABYAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA6ejgtYsdx/9y7T0dPwv5gBVrx+O7zDFjVTS1il/9erL8PDTnXepWlKpusm8rcLvoAETP4xP0z42E4u97u/Hne5yEtHl6PigA7pO6sTK6ONKEXFN0cnvRraVEs1rmyqVK3XVfL/QAKxHbjw7VV1xIABNZzlauzfXNclxOYV6rin4rte3mADxlWWSyS737ewATPhWAAl//9k=")',backgroundSize:'cover',width:'1250px',height:'550px'}}>
            <center><h3 style={{backgroundColor:'lightsteelblue'}}>Saving : Add Amount</h3>
            <Link class='btn btn-outline-warning btnAdd' to={'/useraxios'} block style={{marginTop:'30px'}}>Back to Saving</Link></center><br/>
            <center>
 
            <Card style={{ backgroundColor:'lightgray',width: '23rem',paddingTop:'30px',paddingBottom:'30px',paddingLeft:'15px',paddingRight:'15px'}}>
                    <Form>
                        <Form.Group controlId="formBasicEmail">
                            <Form.Label style={{ float: 'left', marginLeft: "5px" }}>Username : <b>{user.name}</b></Form.Label>
                            {/* <Form.Control type="email" placeholder="Enter Username" /> */}

                        </Form.Group>
                        <Form.Group controlId="formBasicEBal">
                            <Form.Label style={{ marginRight: "170px" }}>Saving Balance : <b>{user.balance}</b></Form.Label>
                        </Form.Group><br/>

                        <Form.Group controlId="formBasicPassword">
                            <Form.Label  style={{ marginRight: "260px" }}>Amount</Form.Label>
                            <Form.Control type="number" placeholder="Enter Amount" onChange={passwordinputvalchange} />
                        </Form.Group>

                        <Button class="btn btn-outline-primary" variant="primary" onClick={onSubmit} block >Add Amount</Button>
                    </Form>
                </Card>
            </center>
        </div>
    )
}
 
export default AddAmount;








// import React, { Fragment, useState, useEffect } from 'react';
// import { Navbar, Button, Card, Form, Row, Col } from 'react-bootstrap';
// import axios from 'axios';
// import { useParams, Link } from 'react-router-dom';


// function AddAmount() {
//     const [user, setUser] = useState({
//         id: '',
//         name: ' ',
//         username: ' ',
//         email: ' ',
//         phone: ' ',
//         balance: 0,
//         transaction: []

//     });
//     const [amount, setAmount] = useState('');

//     const { id } = useParams();
//     useEffect(() => {
//         const res = sessionStorage.getItem('user');
//         let user = JSON.parse(res);
//         getUser(user.id);
//     }, []);

//     const getUser = async (id) => {
//         const res = await axios.get(`http://localhost:3003/users/${id}`);
//         setUser(res.data);
//     }

//     const onSubmit = async e => {
//         e.preventDefault();
//         let date = new Date;
//         let obj = {
//             "type": '',
//             "accountType": '',
//             "dateTime": date,
//             "amount": 0
//         };
//         obj.amount = amount;
//         if (parseInt(amount) > 0) {
//             obj.type = "Credit";
//         } else {
//             obj.type = "Debit";
//         }
//         obj.accountType = "Savings";
//         user.transaction.push(obj);
//         user.balance = parseInt(user.balance) + parseInt(amount);
//         await axios.put(`http://localhost:3003/users/${user.id}`, user);
//         getUser(user.id);
//         alert('Amount added successfully');

//     }
//     const passwordinputvalchange = (e) => {
//         setAmount(e.target.value);

//     }
//     return (
//         <div><center><h3 style={{backgroundColor:'lightsteelblue'}}>Saving : Add Amount</h3>
//             <Link class='btn btn-outline-warning btnAdd' to={'/useraxios'} block style={{marginTop:'30px'}}>Back to Saving</Link><br/><br/>
            

                // <Card style={{ width: '23rem',paddingTop:'30px',paddingBottom:'30px',paddingLeft:'15px',paddingRight:'15px'}}>
                //     <Form>
                //         <Form.Group controlId="formBasicEmail">
                //             <Form.Label style={{ float: 'left', marginLeft: "5px" }}>Username : <b>{user.name}</b></Form.Label>
                //             {/* <Form.Control type="email" placeholder="Enter Username" /> */}

                //         </Form.Group>
                //         <Form.Group controlId="formBasicEBal">
                //             <Form.Label style={{ marginRight: "200px" }}>Saving Balance : <b>{user.balance}</b></Form.Label>
                //         </Form.Group><br/>

                //         <Form.Group controlId="formBasicPassword">
                //             <Form.Label  style={{ marginRight: "260px" }}>Amount</Form.Label>
                //             <Form.Control type="number" placeholder="Enter Amount" onChange={passwordinputvalchange} />
                //         </Form.Group>

                //         <Button class="btn btn-outline-primary" variant="primary" onClick={onSubmit} block >Add Amount</Button>
                //     </Form>
                // </Card>
//             </center>
//         </div>
//     )
// }


// export default AddAmount;