import 'bootstrap/dist/css/bootstrap.min.css';
import { Navbar, Button, Card } from 'react-bootstrap';
import React, { useState } from 'react';
import './App.css';
import { BrowserRouter as Router, Link, Switch, Route, Redirect } from 'react-router-dom';
import Userlogin from './userlogin';
import Usersavingdetails from './usersavingdetails';

function Userdetails() {
    // const[showsavingdetails,setShowsavingdetails]=('false')

    // const savingdetails=()=>{
    //     setShowsavingdetails('true')
    // }
    return (
        <div>
            <Card style={{ width: '23rem',paddingTop:'30px' }}>
            <center><img style={{border:'2px solid black'}}
              alt=""
              src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTitkvCLtsexYuv65RWq8T6K8jIYo9H5rtH5w&usqp=CAU"
              width="100"
              height="100"
              className="d-inline-block align-top"
              
            /></center>
                <Card.Body>
                    <Card.Title>Accounts</Card.Title>
                    <Card.Text>List of Accounts</Card.Text>
                    <Button variant="outline-secondary">Savings</Button>{' '}
                    {/* {
                        showsavingdetails ? <Userlogin/> : null

                    } */}
                    <Button variant="outline-dark">Current</Button>{' '}
                </Card.Body>
            </Card>

        </div>
    )
}

export default Userdetails;